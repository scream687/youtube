#!/usr/bin/env python3
"""
Content Creation System
This module integrates trending discovery, prompt generation, and video generation.
"""

import os
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional

from enhanced_trending_discovery import EnhancedTrendingDiscovery
from prompt_generator import PromptGenerator
from video_generator import VideoGenerator

class ContentCreationSystem:
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the content creation system.
        
        Args:
            config: Configuration dictionary containing API keys and settings
        """
        self.config = config or {}
        
        # Initialize components
        niche_keywords = self.config.get('niche_keywords', [
            'AI', 'artificial intelligence', 'technology', 'automation',
            'machine learning', 'robots', 'future', 'innovation',
            'breakthrough', 'digital', 'tech', 'software'
        ])
        
        self.trending_discovery = EnhancedTrendingDiscovery(niche_keywords)
        self.prompt_generator = PromptGenerator()
        self.video_generator = VideoGenerator(self.config.get('video_api', {}))
        
        # Output directories
        self.output_dir = self.config.get('output_dir', '/tmp/youtube_automation')
        self.videos_dir = os.path.join(self.output_dir, 'videos')
        self.metadata_dir = os.path.join(self.output_dir, 'metadata')
        
        # Create directories
        os.makedirs(self.videos_dir, exist_ok=True)
        os.makedirs(self.metadata_dir, exist_ok=True)
        
        # Content creation settings
        self.max_videos_per_run = self.config.get('max_videos_per_run', 3)
        self.video_duration = self.config.get('video_duration', 'medium')
        self.content_types = self.config.get('content_types', ['technology', 'educational', 'entertainment'])
    
    def discover_content_ideas(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Discover trending content ideas.
        
        Args:
            limit: Maximum number of ideas to discover
            
        Returns:
            List of trending ideas
        """
        print("🔍 Discovering trending content ideas...")
        
        trending_ideas = self.trending_discovery.discover_trending_ideas()
        
        # Filter by content types if specified
        if self.content_types:
            filtered_ideas = [
                idea for idea in trending_ideas 
                if idea.get('content_type') in self.content_types
            ]
        else:
            filtered_ideas = trending_ideas
        
        # Limit results
        selected_ideas = filtered_ideas[:limit]
        
        print(f"✅ Found {len(selected_ideas)} suitable content ideas")
        return selected_ideas
    
    def create_video_content(self, trending_idea: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create video content from a trending idea.
        
        Args:
            trending_idea: The trending idea to create content from
            
        Returns:
            Complete video creation result
        """
        print(f"🎬 Creating video content for: {trending_idea['title'][:50]}...")
        
        # Generate video prompt
        video_prompt = self.prompt_generator.generate_video_prompt(
            trending_idea, 
            duration=self.video_duration
        )
        
        # Generate thumbnail prompt
        thumbnail_prompt = self.prompt_generator.generate_thumbnail_prompt(video_prompt)
        
        # Generate video
        video_result = self.video_generator.generate_complete_video(
            video_prompt, 
            output_dir=self.videos_dir
        )
        
        # Create metadata
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        content_id = f"content_{timestamp}"
        
        metadata = {
            'content_id': content_id,
            'created_at': datetime.now().isoformat(),
            'trending_idea': trending_idea,
            'video_prompt': video_prompt,
            'thumbnail_prompt': thumbnail_prompt,
            'video_result': video_result,
            'status': 'generated' if video_result.get('success') else 'failed',
            'ready_for_upload': video_result.get('success', False)
        }
        
        # Save metadata
        metadata_file = os.path.join(self.metadata_dir, f"{content_id}.json")
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"✅ Video content creation {'completed' if video_result.get('success') else 'failed'}")
        
        return metadata
    
    def batch_create_content(self, num_videos: int = None) -> List[Dict[str, Any]]:
        """
        Create multiple videos in batch.
        
        Args:
            num_videos: Number of videos to create (defaults to max_videos_per_run)
            
        Returns:
            List of creation results
        """
        if num_videos is None:
            num_videos = self.max_videos_per_run
        
        print(f"🚀 Starting batch content creation for {num_videos} videos...")
        
        # Discover trending ideas
        trending_ideas = self.discover_content_ideas(limit=num_videos * 2)  # Get extra ideas as backup
        
        if not trending_ideas:
            print("❌ No trending ideas found. Stopping content creation.")
            return []
        
        created_content = []
        successful_creations = 0
        
        for i, idea in enumerate(trending_ideas[:num_videos]):
            print(f"\n📹 Creating video {i+1}/{num_videos}")
            
            try:
                # Create video content
                content_metadata = self.create_video_content(idea)
                created_content.append(content_metadata)
                
                if content_metadata.get('ready_for_upload'):
                    successful_creations += 1
                    
                    # Mark idea as used in database
                    idea_id = idea.get('id')
                    if idea_id:
                        self.trending_discovery.mark_idea_as_used(idea_id)
                
                # Add delay between creations to avoid rate limiting
                if i < num_videos - 1:
                    print("⏳ Waiting before next creation...")
                    time.sleep(5)
                    
            except Exception as e:
                print(f"❌ Error creating content for idea {i+1}: {str(e)}")
                error_metadata = {
                    'content_id': f"error_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    'created_at': datetime.now().isoformat(),
                    'trending_idea': idea,
                    'error': str(e),
                    'status': 'error',
                    'ready_for_upload': False
                }
                created_content.append(error_metadata)
        
        print(f"\n🎉 Batch creation completed!")
        print(f"📊 Results: {successful_creations}/{num_videos} videos created successfully")
        
        return created_content
    
    def get_ready_content(self) -> List[Dict[str, Any]]:
        """
        Get all content that's ready for upload.
        
        Returns:
            List of content metadata for videos ready to upload
        """
        ready_content = []
        
        if not os.path.exists(self.metadata_dir):
            return ready_content
        
        for filename in os.listdir(self.metadata_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(self.metadata_dir, filename)
                try:
                    with open(filepath, 'r') as f:
                        metadata = json.load(f)
                    
                    if metadata.get('ready_for_upload') and metadata.get('status') == 'generated':
                        ready_content.append(metadata)
                        
                except Exception as e:
                    print(f"Error reading metadata file {filename}: {str(e)}")
        
        # Sort by creation time
        ready_content.sort(key=lambda x: x.get('created_at', ''))
        
        return ready_content
    
    def generate_content_report(self) -> Dict[str, Any]:
        """
        Generate a report of all content creation activities.
        
        Returns:
            Content creation report
        """
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_content': 0,
            'ready_for_upload': 0,
            'failed_creations': 0,
            'content_by_type': {},
            'recent_content': []
        }
        
        if not os.path.exists(self.metadata_dir):
            return report
        
        all_content = []
        
        for filename in os.listdir(self.metadata_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(self.metadata_dir, filename)
                try:
                    with open(filepath, 'r') as f:
                        metadata = json.load(f)
                    all_content.append(metadata)
                except Exception as e:
                    continue
        
        # Calculate statistics
        report['total_content'] = len(all_content)
        
        for content in all_content:
            if content.get('ready_for_upload'):
                report['ready_for_upload'] += 1
            elif content.get('status') == 'error':
                report['failed_creations'] += 1
            
            # Count by content type
            content_type = content.get('trending_idea', {}).get('content_type', 'unknown')
            report['content_by_type'][content_type] = report['content_by_type'].get(content_type, 0) + 1
        
        # Get recent content (last 10)
        all_content.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        report['recent_content'] = all_content[:10]
        
        return report

def main():
    """Test the content creation system."""
    # Configuration
    config = {
        'niche_keywords': [
            'AI', 'artificial intelligence', 'technology', 'automation',
            'machine learning', 'robots', 'future', 'innovation'
        ],
        'video_api': {
            'provider': 'mock_api'  # Using mock API for testing
        },
        'max_videos_per_run': 2,
        'video_duration': 'medium',
        'content_types': ['technology', 'educational'],
        'output_dir': '/tmp/youtube_automation_test'
    }
    
    # Initialize content creation system
    system = ContentCreationSystem(config)
    
    # Create batch content
    print("=== STARTING CONTENT CREATION SYSTEM TEST ===")
    created_content = system.batch_create_content(num_videos=2)
    
    # Display results
    print("\n=== CREATION RESULTS ===")
    for i, content in enumerate(created_content, 1):
        print(f"\nContent {i}:")
        print(f"  ID: {content['content_id']}")
        print(f"  Status: {content['status']}")
        print(f"  Title: {content.get('video_prompt', {}).get('video_title', 'N/A')}")
        print(f"  Ready for Upload: {content['ready_for_upload']}")
    
    # Generate report
    print("\n=== CONTENT REPORT ===")
    report = system.generate_content_report()
    print(f"Total Content Created: {report['total_content']}")
    print(f"Ready for Upload: {report['ready_for_upload']}")
    print(f"Failed Creations: {report['failed_creations']}")
    print(f"Content by Type: {report['content_by_type']}")

if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""
Enhanced Trending Ideas Discovery Component
This module identifies trending topics from multiple sources including Google Trends.
"""

import sys
import json
import requests
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any
import sqlite3
import os
import random

# Add the Manus API client path
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

class EnhancedTrendingDiscovery:
    def __init__(self, niche_keywords: List[str], db_path: str = "enhanced_trending_data.db"):
        """
        Initialize the enhanced trending discovery component.
        
        Args:
            niche_keywords: List of keywords related to the channel's niche
            db_path: Path to SQLite database for storing historical data
        """
        self.niche_keywords = niche_keywords
        self.db_path = db_path
        self.api_client = ApiClient()
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database for storing trending data."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create table for storing trending ideas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trending_ideas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                source TEXT NOT NULL,
                score INTEGER DEFAULT 0,
                keywords TEXT,
                url TEXT,
                trend_strength TEXT DEFAULT 'medium',
                content_type TEXT DEFAULT 'general',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                used BOOLEAN DEFAULT FALSE
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def get_reddit_trends(self, subreddits: List[str] = None) -> List[Dict[str, Any]]:
        """
        Get trending topics from Reddit subreddits.
        
        Args:
            subreddits: List of subreddit names to check
            
        Returns:
            List of trending ideas from Reddit
        """
        if subreddits is None:
            # Expanded list of relevant subreddits for different content types
            subreddits = [
                'videos', 'funny', 'todayilearned', 'askreddit', 'mildlyinteresting',
                'technology', 'artificial', 'MachineLearning', 'programming',
                'science', 'Futurology', 'gadgets', 'startups'
            ]
        
        trending_ideas = []
        
        for subreddit in subreddits:
            try:
                # Use the Reddit API from Manus API Hub
                response = self.api_client.call_api('Reddit/AccessAPI', query={
                    'subreddit': subreddit,
                    'limit': '25'
                })
                
                if response.get('success') and 'posts' in response:
                    for post in response['posts']:
                        post_data = post.get('data', {})
                        
                        # Get post content
                        title = post_data.get('title', '').lower()
                        selftext = post_data.get('selftext', '').lower()
                        combined_text = f"{title} {selftext}"
                        
                        # Check for keyword matches or high engagement
                        matching_keywords = [kw for kw in self.niche_keywords if kw.lower() in combined_text]
                        high_engagement = post_data.get('ups', 0) > 1000 or post_data.get('num_comments', 0) > 100
                        
                        if matching_keywords or high_engagement:
                            # Determine content type based on subreddit
                            content_type = self.categorize_content(subreddit, title)
                            
                            trending_ideas.append({
                                'title': post_data.get('title', ''),
                                'source': f'reddit_{subreddit}',
                                'score': post_data.get('ups', 0),
                                'url': f"https://reddit.com{post_data.get('permalink', '')}",
                                'num_comments': post_data.get('num_comments', 0),
                                'keywords': ', '.join(matching_keywords) if matching_keywords else 'high_engagement',
                                'content_type': content_type
                            })
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                print(f"Error fetching from r/{subreddit}: {str(e)}")
                continue
        
        return trending_ideas
    
    def categorize_content(self, subreddit: str, title: str) -> str:
        """
        Categorize content based on subreddit and title.
        
        Args:
            subreddit: The subreddit name
            title: The post title
            
        Returns:
            Content category string
        """
        tech_subreddits = ['technology', 'artificial', 'MachineLearning', 'programming', 'gadgets']
        educational_subreddits = ['todayilearned', 'science', 'Futurology']
        entertainment_subreddits = ['videos', 'funny', 'mildlyinteresting']
        
        if subreddit in tech_subreddits:
            return 'technology'
        elif subreddit in educational_subreddits:
            return 'educational'
        elif subreddit in entertainment_subreddits:
            return 'entertainment'
        else:
            return 'general'
    
    def generate_synthetic_trends(self) -> List[Dict[str, Any]]:
        """
        Generate synthetic trending ideas based on current tech trends.
        This simulates what would come from Google Trends or other trend APIs.
        
        Returns:
            List of synthetic trending ideas
        """
        synthetic_trends = [
            {
                'title': 'AI Breakthrough in Video Generation Technology',
                'source': 'google_trends',
                'score': 5000,
                'url': 'https://trends.google.com/trends/explore?q=AI+video+generation',
                'keywords': 'AI, video generation, technology',
                'content_type': 'technology',
                'trend_strength': 'high'
            },
            {
                'title': 'Automated Content Creation Tools Surge in Popularity',
                'source': 'google_trends',
                'score': 3500,
                'url': 'https://trends.google.com/trends/explore?q=automated+content+creation',
                'keywords': 'automation, content creation, AI',
                'content_type': 'technology',
                'trend_strength': 'high'
            },
            {
                'title': 'YouTube Automation Strategies for 2025',
                'source': 'trend_analysis',
                'score': 2800,
                'url': 'https://example.com/youtube-automation-2025',
                'keywords': 'YouTube, automation, strategy',
                'content_type': 'educational',
                'trend_strength': 'medium'
            },
            {
                'title': 'Machine Learning Models for Creative Industries',
                'source': 'tech_news',
                'score': 2200,
                'url': 'https://example.com/ml-creative-industries',
                'keywords': 'machine learning, creative, AI',
                'content_type': 'technology',
                'trend_strength': 'medium'
            },
            {
                'title': 'The Future of Passive Income with AI Tools',
                'source': 'business_trends',
                'score': 1900,
                'url': 'https://example.com/passive-income-ai',
                'keywords': 'passive income, AI, automation',
                'content_type': 'educational',
                'trend_strength': 'medium'
            }
        ]
        
        return synthetic_trends
    
    def analyze_and_score_ideas(self, ideas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Enhanced analysis and scoring of trending ideas.
        
        Args:
            ideas: List of trending ideas
            
        Returns:
            Scored and sorted list of ideas
        """
        for idea in ideas:
            # Calculate composite score based on multiple factors
            base_score = idea.get('score', 0)
            comment_score = idea.get('num_comments', 0) * 2
            keyword_match_score = len(idea.get('keywords', '').split(',')) * 100
            
            # Content type multiplier
            content_type = idea.get('content_type', 'general')
            type_multiplier = {
                'technology': 1.5,
                'educational': 1.3,
                'entertainment': 1.2,
                'general': 1.0
            }.get(content_type, 1.0)
            
            # Source credibility multiplier
            source = idea.get('source', '')
            source_multiplier = 1.0
            if 'reddit_technology' in source or 'reddit_artificial' in source:
                source_multiplier = 1.4
            elif 'google_trends' in source:
                source_multiplier = 1.6
            elif 'reddit_videos' in source:
                source_multiplier = 1.2
            
            # Calculate final composite score
            idea['composite_score'] = int((base_score + comment_score + keyword_match_score) * type_multiplier * source_multiplier)
            
            # Determine trend strength
            if idea['composite_score'] > 5000:
                idea['trend_strength'] = 'high'
            elif idea['composite_score'] > 2000:
                idea['trend_strength'] = 'medium'
            else:
                idea['trend_strength'] = 'low'
            
            # Add video potential score
            idea['video_potential'] = self.calculate_video_potential(idea)
        
        # Sort by composite score
        return sorted(ideas, key=lambda x: x.get('composite_score', 0), reverse=True)
    
    def calculate_video_potential(self, idea: Dict[str, Any]) -> str:
        """
        Calculate the potential for creating engaging video content from an idea.
        
        Args:
            idea: The trending idea
            
        Returns:
            Video potential rating (high/medium/low)
        """
        title = idea.get('title', '').lower()
        content_type = idea.get('content_type', 'general')
        
        # High potential indicators
        high_potential_keywords = [
            'breakthrough', 'new', 'amazing', 'incredible', 'shocking',
            'revealed', 'secret', 'hidden', 'discovered', 'future'
        ]
        
        # Medium potential indicators
        medium_potential_keywords = [
            'how to', 'tutorial', 'guide', 'tips', 'tricks',
            'explained', 'analysis', 'review', 'comparison'
        ]
        
        if any(keyword in title for keyword in high_potential_keywords):
            return 'high'
        elif any(keyword in title for keyword in medium_potential_keywords):
            return 'medium'
        elif content_type in ['technology', 'educational']:
            return 'medium'
        else:
            return 'low'
    
    def save_ideas_to_db(self, ideas: List[Dict[str, Any]]):
        """
        Save trending ideas to the database with enhanced metadata.
        
        Args:
            ideas: List of trending ideas to save
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for idea in ideas:
            # Check if idea already exists
            cursor.execute(
                "SELECT id FROM trending_ideas WHERE title = ? AND source = ?",
                (idea['title'], idea['source'])
            )
            
            if not cursor.fetchone():
                cursor.execute('''
                    INSERT INTO trending_ideas (title, source, score, keywords, url, trend_strength, content_type)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    idea['title'],
                    idea['source'],
                    idea.get('composite_score', 0),
                    idea.get('keywords', ''),
                    idea.get('url', ''),
                    idea.get('trend_strength', 'medium'),
                    idea.get('content_type', 'general')
                ))
        
        conn.commit()
        conn.close()
    
    def get_top_unused_ideas(self, limit: int = 10, content_type: str = None) -> List[Dict[str, Any]]:
        """
        Get top unused trending ideas from the database with optional filtering.
        
        Args:
            limit: Maximum number of ideas to return
            content_type: Optional filter by content type
            
        Returns:
            List of top unused trending ideas
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
            SELECT id, title, source, score, keywords, url, trend_strength, content_type, created_at
            FROM trending_ideas
            WHERE used = FALSE
        '''
        params = []
        
        if content_type:
            query += ' AND content_type = ?'
            params.append(content_type)
        
        query += ' ORDER BY score DESC LIMIT ?'
        params.append(limit)
        
        cursor.execute(query, params)
        
        ideas = []
        for row in cursor.fetchall():
            ideas.append({
                'id': row[0],
                'title': row[1],
                'source': row[2],
                'score': row[3],
                'keywords': row[4],
                'url': row[5],
                'trend_strength': row[6],
                'content_type': row[7],
                'created_at': row[8]
            })
        
        conn.close()
        return ideas
    
    def mark_idea_as_used(self, idea_id: int):
        """
        Mark an idea as used in the database.
        
        Args:
            idea_id: ID of the idea to mark as used
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE trending_ideas SET used = TRUE WHERE id = ?",
            (idea_id,)
        )
        
        conn.commit()
        conn.close()
    
    def discover_trending_ideas(self, include_synthetic: bool = True) -> List[Dict[str, Any]]:
        """
        Main method to discover and return trending ideas with enhanced sources.
        
        Args:
            include_synthetic: Whether to include synthetic trend data
            
        Returns:
            List of top trending ideas ready for content creation
        """
        print("Starting enhanced trending ideas discovery...")
        
        # Collect ideas from various sources
        all_ideas = []
        
        # Get Reddit trends
        print("Fetching Reddit trends...")
        reddit_ideas = self.get_reddit_trends()
        all_ideas.extend(reddit_ideas)
        print(f"Found {len(reddit_ideas)} Reddit ideas")
        
        # Get synthetic trends (simulating Google Trends, etc.)
        if include_synthetic:
            print("Generating synthetic trend data...")
            synthetic_ideas = self.generate_synthetic_trends()
            all_ideas.extend(synthetic_ideas)
            print(f"Added {len(synthetic_ideas)} synthetic trends")
        
        # Analyze and score ideas
        print("Analyzing and scoring ideas...")
        scored_ideas = self.analyze_and_score_ideas(all_ideas)
        
        # Save to database
        print("Saving ideas to database...")
        self.save_ideas_to_db(scored_ideas)
        
        # Get top unused ideas
        top_ideas = self.get_top_unused_ideas(limit=15)
        
        print(f"Discovery complete. Found {len(top_ideas)} top trending ideas.")
        return top_ideas

def main():
    """Test the enhanced trending discovery component."""
    # Example niche keywords for a tech/AI channel
    niche_keywords = [
        'AI', 'artificial intelligence', 'technology', 'automation', 
        'machine learning', 'robots', 'future', 'innovation',
        'breakthrough', 'digital', 'tech', 'software'
    ]
    
    # Initialize the enhanced discovery component
    discovery = EnhancedTrendingDiscovery(niche_keywords)
    
    # Discover trending ideas
    trending_ideas = discovery.discover_trending_ideas()
    
    # Display results
    print("\n=== TOP TRENDING IDEAS ===")
    for i, idea in enumerate(trending_ideas[:8], 1):
        print(f"\n{i}. {idea['title']}")
        print(f"   Source: {idea['source']}")
        print(f"   Score: {idea['score']}")
        print(f"   Trend Strength: {idea.get('trend_strength', 'N/A')}")
        print(f"   Content Type: {idea.get('content_type', 'N/A')}")
        print(f"   Keywords: {idea['keywords']}")
        print(f"   URL: {idea['url']}")

if __name__ == "__main__":
    main()


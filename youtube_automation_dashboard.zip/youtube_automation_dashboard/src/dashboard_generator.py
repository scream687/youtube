#!/usr/bin/env python3
"""
Dashboard Generator Module
This module creates visual dashboards and reports from YouTube analytics data.
"""

import os
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import seaborn as sns
import numpy as np
from io import BytesIO
import base64

class DashboardGenerator:
    def __init__(self, analytics_db_path: str = 'youtube_analytics.db'):
        """
        Initialize the dashboard generator.
        
        Args:
            analytics_db_path: Path to the analytics database
        """
        self.db_path = analytics_db_path
        
        # Set up matplotlib style
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        # Dashboard configuration
        self.figure_size = (12, 8)
        self.dpi = 100
        self.output_dir = '/tmp/youtube_dashboards'
        
        # Create output directory
        os.makedirs(self.output_dir, exist_ok=True)
    
    def get_analytics_data(self, days: int = 30) -> pd.DataFrame:
        """
        Get analytics data from the database as a pandas DataFrame.
        
        Args:
            days: Number of days of data to retrieve
            
        Returns:
            DataFrame with analytics data
        """
        conn = sqlite3.connect(self.db_path)
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        query = '''
            SELECT 
                v.video_id, v.title, v.content_type, v.trending_source, v.upload_date,
                a.date_recorded, a.views, a.likes, a.dislikes, a.comments, a.shares,
                a.watch_time_minutes, a.subscribers_gained, a.revenue_usd,
                a.ctr_percentage, a.avg_view_duration_seconds
            FROM videos v
            LEFT JOIN analytics a ON v.video_id = a.video_id
            WHERE a.date_recorded >= ?
            ORDER BY a.date_recorded DESC
        '''
        
        df = pd.read_sql_query(query, conn, params=(start_date.isoformat(),))
        conn.close()
        
        # Convert date columns
        if not df.empty:
            df['upload_date'] = pd.to_datetime(df['upload_date'])
            df['date_recorded'] = pd.to_datetime(df['date_recorded'])
        
        return df
    
    def create_views_trend_chart(self, df: pd.DataFrame, output_path: str = None) -> str:
        """
        Create a chart showing views trend over time.
        
        Args:
            df: Analytics DataFrame
            output_path: Path to save the chart
            
        Returns:
            Path to the saved chart
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, 'views_trend.png')
        
        plt.figure(figsize=self.figure_size, dpi=self.dpi)
        
        if df.empty:
            plt.text(0.5, 0.5, 'No data available', ha='center', va='center', 
                    transform=plt.gca().transAxes, fontsize=16)
            plt.title('Views Trend Over Time')
        else:
            # Group by date and sum views
            daily_views = df.groupby(df['date_recorded'].dt.date)['views'].sum().reset_index()
            daily_views['date_recorded'] = pd.to_datetime(daily_views['date_recorded'])
            
            plt.plot(daily_views['date_recorded'], daily_views['views'], 
                    marker='o', linewidth=2, markersize=6)
            plt.title('Daily Views Trend', fontsize=16, fontweight='bold')
            plt.xlabel('Date', fontsize=12)
            plt.ylabel('Total Views', fontsize=12)
            plt.grid(True, alpha=0.3)
            
            # Format x-axis
            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
            plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(daily_views)//10)))
            plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.savefig(output_path, bbox_inches='tight', facecolor='white')
        plt.close()
        
        return output_path
    
    def create_content_type_performance_chart(self, df: pd.DataFrame, output_path: str = None) -> str:
        """
        Create a chart showing performance by content type.
        
        Args:
            df: Analytics DataFrame
            output_path: Path to save the chart
            
        Returns:
            Path to the saved chart
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, 'content_type_performance.png')
        
        plt.figure(figsize=self.figure_size, dpi=self.dpi)
        
        if df.empty:
            plt.text(0.5, 0.5, 'No data available', ha='center', va='center', 
                    transform=plt.gca().transAxes, fontsize=16)
            plt.title('Content Type Performance')
        else:
            # Group by content type
            content_performance = df.groupby('content_type').agg({
                'views': 'sum',
                'likes': 'sum',
                'comments': 'sum',
                'revenue_usd': 'sum'
            }).reset_index()
            
            # Create subplots
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
            
            # Views by content type
            ax1.bar(content_performance['content_type'], content_performance['views'])
            ax1.set_title('Total Views by Content Type')
            ax1.set_ylabel('Views')
            ax1.tick_params(axis='x', rotation=45)
            
            # Likes by content type
            ax2.bar(content_performance['content_type'], content_performance['likes'])
            ax2.set_title('Total Likes by Content Type')
            ax2.set_ylabel('Likes')
            ax2.tick_params(axis='x', rotation=45)
            
            # Comments by content type
            ax3.bar(content_performance['content_type'], content_performance['comments'])
            ax3.set_title('Total Comments by Content Type')
            ax3.set_ylabel('Comments')
            ax3.tick_params(axis='x', rotation=45)
            
            # Revenue by content type
            ax4.bar(content_performance['content_type'], content_performance['revenue_usd'])
            ax4.set_title('Total Revenue by Content Type')
            ax4.set_ylabel('Revenue (USD)')
            ax4.tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            plt.savefig(output_path, bbox_inches='tight', facecolor='white')
            plt.close()
            
            return output_path
        
        plt.tight_layout()
        plt.savefig(output_path, bbox_inches='tight', facecolor='white')
        plt.close()
        
        return output_path
    
    def create_top_videos_chart(self, df: pd.DataFrame, top_n: int = 10, output_path: str = None) -> str:
        """
        Create a chart showing top performing videos.
        
        Args:
            df: Analytics DataFrame
            top_n: Number of top videos to show
            output_path: Path to save the chart
            
        Returns:
            Path to the saved chart
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, 'top_videos.png')
        
        plt.figure(figsize=(14, 8), dpi=self.dpi)
        
        if df.empty:
            plt.text(0.5, 0.5, 'No data available', ha='center', va='center', 
                    transform=plt.gca().transAxes, fontsize=16)
            plt.title('Top Performing Videos')
        else:
            # Get top videos by views
            top_videos = df.nlargest(top_n, 'views')[['title', 'views', 'likes', 'comments']]
            
            # Truncate long titles
            top_videos['short_title'] = top_videos['title'].apply(
                lambda x: x[:30] + '...' if len(x) > 30 else x
            )
            
            # Create horizontal bar chart
            y_pos = range(len(top_videos))
            
            plt.barh(y_pos, top_videos['views'], alpha=0.8)
            plt.yticks(y_pos, top_videos['short_title'])
            plt.xlabel('Views')
            plt.title(f'Top {top_n} Videos by Views', fontsize=16, fontweight='bold')
            plt.grid(axis='x', alpha=0.3)
            
            # Add value labels on bars
            for i, v in enumerate(top_videos['views']):
                plt.text(v + max(top_videos['views']) * 0.01, i, f'{v:,}', 
                        va='center', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(output_path, bbox_inches='tight', facecolor='white')
        plt.close()
        
        return output_path
    
    def create_engagement_metrics_chart(self, df: pd.DataFrame, output_path: str = None) -> str:
        """
        Create a chart showing engagement metrics.
        
        Args:
            df: Analytics DataFrame
            output_path: Path to save the chart
            
        Returns:
            Path to the saved chart
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, 'engagement_metrics.png')
        
        plt.figure(figsize=self.figure_size, dpi=self.dpi)
        
        if df.empty:
            plt.text(0.5, 0.5, 'No data available', ha='center', va='center', 
                    transform=plt.gca().transAxes, fontsize=16)
            plt.title('Engagement Metrics')
        else:
            # Calculate engagement rate (likes + comments) / views
            df['engagement_rate'] = ((df['likes'] + df['comments']) / df['views'] * 100).fillna(0)
            
            # Create scatter plot
            plt.scatter(df['views'], df['engagement_rate'], alpha=0.6, s=60)
            plt.xlabel('Views')
            plt.ylabel('Engagement Rate (%)')
            plt.title('Engagement Rate vs Views', fontsize=16, fontweight='bold')
            plt.grid(True, alpha=0.3)
            
            # Add trend line
            if len(df) > 1:
                z = np.polyfit(df['views'], df['engagement_rate'], 1)
                p = np.poly1d(z)
                plt.plot(df['views'], p(df['views']), "r--", alpha=0.8, linewidth=2)
        
        plt.tight_layout()
        plt.savefig(output_path, bbox_inches='tight', facecolor='white')
        plt.close()
        
        return output_path
    
    def create_revenue_analysis_chart(self, df: pd.DataFrame, output_path: str = None) -> str:
        """
        Create a chart showing revenue analysis.
        
        Args:
            df: Analytics DataFrame
            output_path: Path to save the chart
            
        Returns:
            Path to the saved chart
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, 'revenue_analysis.png')
        
        plt.figure(figsize=self.figure_size, dpi=self.dpi)
        
        if df.empty:
            plt.text(0.5, 0.5, 'No data available', ha='center', va='center', 
                    transform=plt.gca().transAxes, fontsize=16)
            plt.title('Revenue Analysis')
        else:
            # Group by date and sum revenue
            daily_revenue = df.groupby(df['date_recorded'].dt.date)['revenue_usd'].sum().reset_index()
            daily_revenue['date_recorded'] = pd.to_datetime(daily_revenue['date_recorded'])
            
            # Create area chart
            plt.fill_between(daily_revenue['date_recorded'], daily_revenue['revenue_usd'], 
                           alpha=0.7, color='green')
            plt.plot(daily_revenue['date_recorded'], daily_revenue['revenue_usd'], 
                    color='darkgreen', linewidth=2)
            
            plt.title('Daily Revenue Trend', fontsize=16, fontweight='bold')
            plt.xlabel('Date')
            plt.ylabel('Revenue (USD)')
            plt.grid(True, alpha=0.3)
            
            # Format x-axis
            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
            plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(daily_revenue)//10)))
            plt.xticks(rotation=45)
            
            # Add total revenue text
            total_revenue = df['revenue_usd'].sum()
            plt.text(0.02, 0.98, f'Total Revenue: ${total_revenue:.2f}', 
                    transform=plt.gca().transAxes, fontsize=12, fontweight='bold',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plt.savefig(output_path, bbox_inches='tight', facecolor='white')
        plt.close()
        
        return output_path
    
    def generate_complete_dashboard(self, days: int = 30) -> Dict[str, str]:
        """
        Generate a complete dashboard with all charts.
        
        Args:
            days: Number of days of data to include
            
        Returns:
            Dictionary with paths to all generated charts
        """
        print(f"📊 Generating complete dashboard for last {days} days...")
        
        # Get data
        df = self.get_analytics_data(days)
        
        if df.empty:
            print("⚠️  No analytics data found")
            return {}
        
        # Generate all charts
        chart_paths = {}
        
        print("Creating views trend chart...")
        chart_paths['views_trend'] = self.create_views_trend_chart(df)
        
        print("Creating content type performance chart...")
        chart_paths['content_performance'] = self.create_content_type_performance_chart(df)
        
        print("Creating top videos chart...")
        chart_paths['top_videos'] = self.create_top_videos_chart(df)
        
        print("Creating engagement metrics chart...")
        chart_paths['engagement_metrics'] = self.create_engagement_metrics_chart(df)
        
        print("Creating revenue analysis chart...")
        chart_paths['revenue_analysis'] = self.create_revenue_analysis_chart(df)
        
        # Generate summary statistics
        summary_stats = {
            'total_videos': len(df['video_id'].unique()),
            'total_views': int(df['views'].sum()),
            'total_likes': int(df['likes'].sum()),
            'total_comments': int(df['comments'].sum()),
            'total_revenue': round(df['revenue_usd'].sum(), 2),
            'avg_ctr': round(df['ctr_percentage'].mean(), 2),
            'avg_engagement_rate': round(((df['likes'] + df['comments']) / df['views'] * 100).mean(), 2)
        }
        
        # Save summary to JSON
        summary_path = os.path.join(self.output_dir, 'dashboard_summary.json')
        with open(summary_path, 'w') as f:
            json.dump(summary_stats, f, indent=2)
        
        chart_paths['summary'] = summary_path
        
        print("✅ Complete dashboard generated successfully!")
        print(f"📁 Dashboard files saved to: {self.output_dir}")
        
        return chart_paths

def main():
    """Test the dashboard generator."""
    import numpy as np
    
    # Initialize dashboard generator
    dashboard = DashboardGenerator('/tmp/test_youtube_analytics.db')
    
    print("=== TESTING DASHBOARD GENERATOR ===")
    
    # Generate complete dashboard
    chart_paths = dashboard.generate_complete_dashboard(days=30)
    
    print("\n=== GENERATED CHARTS ===")
    for chart_name, path in chart_paths.items():
        if os.path.exists(path):
            print(f"✅ {chart_name}: {path}")
        else:
            print(f"❌ {chart_name}: File not found")
    
    # Display summary if available
    if 'summary' in chart_paths:
        with open(chart_paths['summary'], 'r') as f:
            summary = json.load(f)
        
        print("\n=== DASHBOARD SUMMARY ===")
        print(f"Total Videos: {summary['total_videos']}")
        print(f"Total Views: {summary['total_views']:,}")
        print(f"Total Likes: {summary['total_likes']:,}")
        print(f"Total Revenue: ${summary['total_revenue']:.2f}")
        print(f"Average CTR: {summary['avg_ctr']:.2f}%")
        print(f"Average Engagement Rate: {summary['avg_engagement_rate']:.2f}%")

if __name__ == "__main__":
    main()


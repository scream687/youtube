#!/usr/bin/env python3
"""
Test script to verify Reddit API functionality
"""

import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

def test_reddit_api():
    """Test the Reddit API to see what data we can get."""
    client = ApiClient()
    
    try:
        # Test with a popular subreddit
        response = client.call_api('Reddit/AccessAPI', query={
            'subreddit': 'videos',
            'limit': '5'
        })
        
        print("Reddit API Response:")
        print(f"Success: {response.get('success')}")
        
        if response.get('success') and 'posts' in response:
            print(f"Number of posts: {len(response['posts'])}")
            
            for i, post in enumerate(response['posts'][:3], 1):
                post_data = post.get('data', {})
                print(f"\nPost {i}:")
                print(f"  Title: {post_data.get('title', 'N/A')}")
                print(f"  Score: {post_data.get('ups', 0)}")
                print(f"  Comments: {post_data.get('num_comments', 0)}")
                print(f"  Subreddit: {post_data.get('subreddit', 'N/A')}")
        else:
            print("No posts found or API call failed")
            print(f"Response: {response}")
            
    except Exception as e:
        print(f"Error testing Reddit API: {str(e)}")

if __name__ == "__main__":
    test_reddit_api()


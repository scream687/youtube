from flask import Blueprint, jsonify, request
from src.automation_orchestrator import AutomationOrchestrator
from src.analytics_tracker import AnalyticsTracker
from src.dashboard_generator import DashboardGenerator
import os
import json

automation_bp = Blueprint('automation', __name__)

# Initialize components
orchestrator = AutomationOrchestrator('/home/ubuntu/youtube_automation_dashboard/src/automation_config.json')
analytics_tracker = AnalyticsTracker()
dashboard_generator = DashboardGenerator()

@automation_bp.route('/status', methods=['GET'])
def get_status():
    """Get the current status of the automation system."""
    try:
        status = orchestrator.get_system_status()
        return jsonify({
            'success': True,
            'data': status
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/run-manual', methods=['POST'])
def run_manual():
    """Run the automation workflow manually."""
    try:
        data = request.get_json() or {}
        num_videos = data.get('num_videos', 1)
        
        orchestrator.run_manual_workflow(num_videos)
        
        return jsonify({
            'success': True,
            'message': f'Manual workflow completed for {num_videos} videos'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/analytics/report', methods=['GET'])
def get_analytics_report():
    """Get analytics performance report."""
    try:
        days = request.args.get('days', 30, type=int)
        report = analytics_tracker.generate_performance_report(days)
        
        return jsonify({
            'success': True,
            'data': report
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/analytics/dashboard', methods=['GET'])
def generate_dashboard():
    """Generate analytics dashboard."""
    try:
        days = request.args.get('days', 30, type=int)
        chart_paths = dashboard_generator.generate_complete_dashboard(days)
        
        # Convert absolute paths to relative paths for web serving
        web_paths = {}
        for chart_name, path in chart_paths.items():
            if path.endswith('.png'):
                filename = os.path.basename(path)
                # Copy to static directory
                static_path = f'/home/ubuntu/youtube_automation_dashboard/src/static/{filename}'
                os.system(f'cp "{path}" "{static_path}"')
                web_paths[chart_name] = f'/{filename}'
            elif path.endswith('.json'):
                with open(path, 'r') as f:
                    web_paths[chart_name] = json.load(f)
        
        return jsonify({
            'success': True,
            'data': web_paths
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/content/ready', methods=['GET'])
def get_ready_content():
    """Get content ready for upload."""
    try:
        ready_content = orchestrator.content_system.get_ready_content()
        
        return jsonify({
            'success': True,
            'data': ready_content
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/config', methods=['GET'])
def get_config():
    """Get current automation configuration."""
    try:
        return jsonify({
            'success': True,
            'data': orchestrator.config
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/config', methods=['POST'])
def update_config():
    """Update automation configuration."""
    try:
        new_config = request.get_json()
        
        # Update configuration
        orchestrator.config.update(new_config)
        
        # Save to file
        with open(orchestrator.config_path, 'w') as f:
            json.dump(orchestrator.config, f, indent=2)
        
        return jsonify({
            'success': True,
            'message': 'Configuration updated successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@automation_bp.route('/logs', methods=['GET'])
def get_logs():
    """Get recent automation logs."""
    try:
        log_file = orchestrator.config.get('log_file', 'youtube_automation.log')
        
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                lines = f.readlines()
                # Get last 100 lines
                recent_logs = lines[-100:] if len(lines) > 100 else lines
        else:
            recent_logs = ['No log file found']
        
        return jsonify({
            'success': True,
            'data': recent_logs
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


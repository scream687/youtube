#!/usr/bin/env python3
"""
Prompt Generator Module
This module generates detailed prompts for AI video generation based on trending ideas.
"""

import json
import random
from typing import Dict, List, Any
from datetime import datetime

class PromptGenerator:
    def __init__(self):
        """Initialize the prompt generator with templates and styles."""
        self.video_styles = [
            "cinematic", "documentary", "modern", "futuristic", "minimalist",
            "vibrant", "professional", "engaging", "dynamic", "sleek"
        ]
        
        self.video_templates = {
            'technology': {
                'intro': [
                    "A sleek, modern introduction showcasing cutting-edge technology",
                    "Futuristic digital interface with glowing elements and data streams",
                    "Clean, professional tech workspace with multiple screens"
                ],
                'main_content': [
                    "Animated infographics explaining the technology concept",
                    "Split-screen comparison showing before and after scenarios",
                    "3D visualization of the technological process or innovation"
                ],
                'outro': [
                    "Call-to-action with subscribe button and related video suggestions",
                    "Summary of key points with animated text overlays",
                    "Professional closing with channel branding"
                ]
            },
            'educational': {
                'intro': [
                    "Engaging hook with intriguing question or surprising fact",
                    "Clean, academic-style introduction with title animation",
                    "Documentary-style opening with relevant background imagery"
                ],
                'main_content': [
                    "Step-by-step explanation with clear visual aids",
                    "Historical timeline with smooth transitions",
                    "Animated diagrams and charts explaining complex concepts"
                ],
                'outro': [
                    "Summary of learned concepts with key takeaways",
                    "Encouragement to explore related topics",
                    "Educational call-to-action for further learning"
                ]
            },
            'entertainment': {
                'intro': [
                    "High-energy opening with upbeat music and quick cuts",
                    "Humorous hook that immediately grabs attention",
                    "Colorful, dynamic introduction with engaging visuals"
                ],
                'main_content': [
                    "Fast-paced montage with entertaining transitions",
                    "Reaction-style content with expressive visual elements",
                    "Compilation format with smooth flow between segments"
                ],
                'outro': [
                    "Fun closing with memorable catchphrase or joke",
                    "Energetic call-to-action for likes and subscriptions",
                    "Preview of upcoming entertaining content"
                ]
            }
        }
        
        self.duration_templates = {
            'short': {'duration': '30-60 seconds', 'segments': 3},
            'medium': {'duration': '2-5 minutes', 'segments': 5},
            'long': {'duration': '8-12 minutes', 'segments': 8}
        }
    
    def generate_video_title(self, trending_idea: Dict[str, Any]) -> str:
        """
        Generate an engaging video title based on the trending idea.
        
        Args:
            trending_idea: The trending idea data
            
        Returns:
            Optimized video title
        """
        original_title = trending_idea.get('title', '')
        content_type = trending_idea.get('content_type', 'general')
        keywords = trending_idea.get('keywords', '').split(',')
        
        # Title enhancement patterns
        enhancement_patterns = {
            'technology': [
                "🚀 {title} - The Future is Here!",
                "BREAKING: {title} Changes Everything",
                "How {title} Will Transform Your Life",
                "The Truth About {title} (Mind-Blowing!)"
            ],
            'educational': [
                "What You Need to Know About {title}",
                "The Complete Guide to {title}",
                "5 Things You Didn't Know About {title}",
                "Why {title} Matters More Than You Think"
            ],
            'entertainment': [
                "You Won't Believe {title}! 😱",
                "This {title} Will Make Your Day!",
                "HILARIOUS: {title} Goes Viral",
                "The {title} That Broke the Internet"
            ]
        }
        
        patterns = enhancement_patterns.get(content_type, enhancement_patterns['educational'])
        selected_pattern = random.choice(patterns)
        
        # Clean and optimize the title
        clean_title = self.clean_title_for_youtube(original_title)
        enhanced_title = selected_pattern.format(title=clean_title)
        
        # Ensure title is within YouTube's character limit
        if len(enhanced_title) > 100:
            enhanced_title = enhanced_title[:97] + "..."
        
        return enhanced_title
    
    def clean_title_for_youtube(self, title: str) -> str:
        """
        Clean and optimize title for YouTube.
        
        Args:
            title: Original title
            
        Returns:
            Cleaned title
        """
        # Remove Reddit-specific prefixes
        prefixes_to_remove = ['TIL', 'TIL that', 'LPT:', 'PSA:', 'TIFU']
        for prefix in prefixes_to_remove:
            if title.startswith(prefix):
                title = title[len(prefix):].strip()
        
        # Capitalize first letter
        if title:
            title = title[0].upper() + title[1:]
        
        return title
    
    def generate_video_description(self, trending_idea: Dict[str, Any], video_title: str) -> str:
        """
        Generate a comprehensive video description.
        
        Args:
            trending_idea: The trending idea data
            video_title: The generated video title
            
        Returns:
            Video description
        """
        keywords = trending_idea.get('keywords', '').split(',')
        source_url = trending_idea.get('url', '')
        content_type = trending_idea.get('content_type', 'general')
        
        description_parts = [
            f"🎯 {video_title}",
            "",
            "In this video, we explore the fascinating topic that's been trending across social media and news platforms.",
            "",
            "🔍 What you'll learn:",
            "• Key insights and important details",
            "• Why this topic is trending right now",
            "• What this means for the future",
            "",
            "📊 This content is based on trending discussions and verified sources.",
            "",
            "🔔 Don't forget to LIKE and SUBSCRIBE for more trending content!",
            "",
            "📱 Follow us for daily updates on the latest trends and breaking news.",
            "",
            "#Trending #Viral #News #Technology #AI #Automation",
            "",
            f"Source discussion: {source_url}" if source_url else "",
            "",
            "⚠️ Disclaimer: This content is for educational and entertainment purposes.",
            "",
            f"Generated on: {datetime.now().strftime('%Y-%m-%d')}"
        ]
        
        return "\n".join(description_parts)
    
    def generate_video_tags(self, trending_idea: Dict[str, Any]) -> List[str]:
        """
        Generate relevant tags for the video.
        
        Args:
            trending_idea: The trending idea data
            
        Returns:
            List of video tags
        """
        base_tags = ['trending', 'viral', 'news', 'latest', 'breaking']
        content_type = trending_idea.get('content_type', 'general')
        keywords = [kw.strip() for kw in trending_idea.get('keywords', '').split(',') if kw.strip()]
        
        # Content-specific tags
        type_tags = {
            'technology': ['tech', 'innovation', 'AI', 'future', 'digital', 'automation'],
            'educational': ['learn', 'education', 'facts', 'knowledge', 'explained', 'guide'],
            'entertainment': ['funny', 'amazing', 'incredible', 'wow', 'cool', 'awesome']
        }
        
        all_tags = base_tags + type_tags.get(content_type, []) + keywords
        
        # Remove duplicates and limit to 15 tags (YouTube recommendation)
        unique_tags = list(dict.fromkeys(all_tags))[:15]
        
        return unique_tags
    
    def generate_video_prompt(self, trending_idea: Dict[str, Any], duration: str = 'medium') -> Dict[str, Any]:
        """
        Generate a comprehensive video prompt for AI video generation.
        
        Args:
            trending_idea: The trending idea data
            duration: Video duration ('short', 'medium', 'long')
            
        Returns:
            Complete video prompt and metadata
        """
        content_type = trending_idea.get('content_type', 'general')
        title = trending_idea.get('title', '')
        
        # Get templates for this content type
        templates = self.video_templates.get(content_type, self.video_templates['educational'])
        duration_info = self.duration_templates.get(duration, self.duration_templates['medium'])
        
        # Generate video segments
        segments = []
        
        # Intro segment
        intro_template = random.choice(templates['intro'])
        segments.append({
            'type': 'intro',
            'duration': '5-10 seconds',
            'prompt': f"{intro_template}. The video introduces the topic: '{title}'. Style: {random.choice(self.video_styles)}, high quality, professional lighting."
        })
        
        # Main content segments
        main_template = random.choice(templates['main_content'])
        num_main_segments = duration_info['segments'] - 2  # Subtract intro and outro
        
        for i in range(num_main_segments):
            segments.append({
                'type': 'main_content',
                'duration': f'{duration_info["duration"].split("-")[0]}-{duration_info["duration"].split("-")[1]}',
                'prompt': f"{main_template}. Focus on explaining: '{title}'. Segment {i+1} of {num_main_segments}. Visual style: {random.choice(self.video_styles)}, engaging transitions, clear typography."
            })
        
        # Outro segment
        outro_template = random.choice(templates['outro'])
        segments.append({
            'type': 'outro',
            'duration': '5-10 seconds',
            'prompt': f"{outro_template}. Conclude the video about: '{title}'. Style: {random.choice(self.video_styles)}, call-to-action elements, professional branding."
        })
        
        # Generate metadata
        video_title = self.generate_video_title(trending_idea)
        video_description = self.generate_video_description(trending_idea, video_title)
        video_tags = self.generate_video_tags(trending_idea)
        
        return {
            'video_title': video_title,
            'video_description': video_description,
            'video_tags': video_tags,
            'segments': segments,
            'total_duration': duration_info['duration'],
            'content_type': content_type,
            'style': random.choice(self.video_styles),
            'aspect_ratio': '16:9',
            'quality': 'HD',
            'source_idea': trending_idea
        }
    
    def generate_thumbnail_prompt(self, video_prompt: Dict[str, Any]) -> str:
        """
        Generate a prompt for creating an eye-catching thumbnail.
        
        Args:
            video_prompt: The generated video prompt
            
        Returns:
            Thumbnail generation prompt
        """
        title = video_prompt['video_title']
        content_type = video_prompt['content_type']
        style = video_prompt['style']
        
        thumbnail_elements = {
            'technology': [
                "futuristic digital interface", "glowing circuit patterns", "holographic displays",
                "sleek tech devices", "data visualization", "AI neural networks"
            ],
            'educational': [
                "clean infographic elements", "academic symbols", "book and learning icons",
                "lightbulb representing ideas", "graduation cap", "knowledge symbols"
            ],
            'entertainment': [
                "bright colorful background", "excited facial expressions", "fun graphic elements",
                "party or celebration themes", "dynamic action poses", "emoji reactions"
            ]
        }
        
        elements = thumbnail_elements.get(content_type, thumbnail_elements['educational'])
        selected_elements = random.sample(elements, min(2, len(elements)))
        
        thumbnail_prompt = f"""
        Create a YouTube thumbnail for the video titled: "{title}"
        
        Visual elements: {', '.join(selected_elements)}
        Style: {style}, eye-catching, high contrast
        Text overlay: Large, bold title text that's easy to read
        Color scheme: Vibrant and attention-grabbing
        Composition: Rule of thirds, focal point on main subject
        Quality: High resolution, professional design
        Emotion: Convey curiosity and engagement
        
        The thumbnail should make viewers want to click and watch the video.
        """
        
        return thumbnail_prompt.strip()

def main():
    """Test the prompt generator."""
    # Sample trending idea
    sample_idea = {
        'title': 'AI Technology Breakthrough in Video Generation',
        'source': 'google_trends',
        'score': 5000,
        'keywords': 'AI, video generation, technology',
        'content_type': 'technology',
        'trend_strength': 'high',
        'url': 'https://example.com/ai-breakthrough'
    }
    
    # Initialize prompt generator
    generator = PromptGenerator()
    
    # Generate video prompt
    video_prompt = generator.generate_video_prompt(sample_idea, duration='medium')
    
    # Display results
    print("=== GENERATED VIDEO PROMPT ===")
    print(f"Title: {video_prompt['video_title']}")
    print(f"Duration: {video_prompt['total_duration']}")
    print(f"Style: {video_prompt['style']}")
    print(f"Content Type: {video_prompt['content_type']}")
    
    print("\n=== VIDEO SEGMENTS ===")
    for i, segment in enumerate(video_prompt['segments'], 1):
        print(f"\nSegment {i} ({segment['type']}):")
        print(f"Duration: {segment['duration']}")
        print(f"Prompt: {segment['prompt']}")
    
    print(f"\n=== DESCRIPTION ===")
    print(video_prompt['video_description'])
    
    print(f"\n=== TAGS ===")
    print(", ".join(video_prompt['video_tags']))
    
    print(f"\n=== THUMBNAIL PROMPT ===")
    thumbnail_prompt = generator.generate_thumbnail_prompt(video_prompt)
    print(thumbnail_prompt)

if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""
Trending Ideas Discovery Component
This module identifies trending topics and generates content ideas for YouTube automation.
"""

import sys
import json
import requests
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any
import sqlite3
import os

# Add the Manus API client path
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

class TrendingDiscovery:
    def __init__(self, niche_keywords: List[str], db_path: str = "trending_data.db"):
        """
        Initialize the trending discovery component.
        
        Args:
            niche_keywords: List of keywords related to the channel's niche
            db_path: Path to SQLite database for storing historical data
        """
        self.niche_keywords = niche_keywords
        self.db_path = db_path
        self.api_client = ApiClient()
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database for storing trending data."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create table for storing trending ideas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trending_ideas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                source TEXT NOT NULL,
                score INTEGER DEFAULT 0,
                keywords TEXT,
                url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                used BOOLEAN DEFAULT FALSE
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def get_reddit_trends(self, subreddits: List[str] = None) -> List[Dict[str, Any]]:
        """
        Get trending topics from Reddit subreddits.
        
        Args:
            subreddits: List of subreddit names to check
            
        Returns:
            List of trending ideas from Reddit
        """
        if subreddits is None:
            subreddits = ['videos', 'funny', 'todayilearned', 'askreddit', 'mildlyinteresting']
        
        trending_ideas = []
        
        for subreddit in subreddits:
            try:
                # Use the Reddit API from Manus API Hub
                response = self.api_client.call_api('Reddit/AccessAPI', query={
                    'subreddit': subreddit,
                    'limit': '25'
                })
                
                if response.get('success') and 'posts' in response:
                    for post in response['posts']:
                        post_data = post.get('data', {})
                        
                        # Filter posts based on niche keywords (more flexible matching)
                        title = post_data.get('title', '').lower()
                        selftext = post_data.get('selftext', '').lower()
                        combined_text = f"{title} {selftext}"
                        
                        matching_keywords = [kw for kw in self.niche_keywords if kw.lower() in combined_text]
                        
                        if matching_keywords:
                            trending_ideas.append({
                                'title': post_data.get('title', ''),
                                'source': f'reddit_{subreddit}',
                                'score': post_data.get('ups', 0),
                                'url': f"https://reddit.com{post_data.get('permalink', '')}",
                                'num_comments': post_data.get('num_comments', 0),
                                'keywords': ', '.join(matching_keywords)
                            })
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                print(f"Error fetching from r/{subreddit}: {str(e)}")
                continue
        
        return trending_ideas
    
    def get_youtube_trends(self) -> List[Dict[str, Any]]:
        """
        Get trending topics from YouTube (placeholder - would need YouTube API).
        
        Returns:
            List of trending ideas from YouTube
        """
        # This is a placeholder implementation
        # In a real implementation, you would use the YouTube Data API
        # to get trending videos and search trends
        
        trending_ideas = []
        
        # Placeholder data structure
        placeholder_trends = [
            {
                'title': 'AI Technology Breakthrough',
                'source': 'youtube_trending',
                'score': 1000000,
                'url': 'https://youtube.com/watch?v=placeholder',
                'keywords': 'AI, technology, breakthrough'
            }
        ]
        
        return placeholder_trends
    
    def analyze_and_score_ideas(self, ideas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Analyze and score trending ideas based on various factors.
        
        Args:
            ideas: List of trending ideas
            
        Returns:
            Scored and sorted list of ideas
        """
        for idea in ideas:
            # Calculate composite score based on multiple factors
            base_score = idea.get('score', 0)
            comment_score = idea.get('num_comments', 0) * 2  # Comments are valuable
            keyword_match_score = len(idea.get('keywords', '').split(',')) * 100
            
            # Composite scoring
            idea['composite_score'] = base_score + comment_score + keyword_match_score
            
            # Add trend strength indicator
            if idea['composite_score'] > 1000:
                idea['trend_strength'] = 'high'
            elif idea['composite_score'] > 500:
                idea['trend_strength'] = 'medium'
            else:
                idea['trend_strength'] = 'low'
        
        # Sort by composite score
        return sorted(ideas, key=lambda x: x.get('composite_score', 0), reverse=True)
    
    def save_ideas_to_db(self, ideas: List[Dict[str, Any]]):
        """
        Save trending ideas to the database.
        
        Args:
            ideas: List of trending ideas to save
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for idea in ideas:
            # Check if idea already exists
            cursor.execute(
                "SELECT id FROM trending_ideas WHERE title = ? AND source = ?",
                (idea['title'], idea['source'])
            )
            
            if not cursor.fetchone():
                cursor.execute('''
                    INSERT INTO trending_ideas (title, source, score, keywords, url)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    idea['title'],
                    idea['source'],
                    idea.get('composite_score', 0),
                    idea.get('keywords', ''),
                    idea.get('url', '')
                ))
        
        conn.commit()
        conn.close()
    
    def get_top_unused_ideas(self, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Get top unused trending ideas from the database.
        
        Args:
            limit: Maximum number of ideas to return
            
        Returns:
            List of top unused trending ideas
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, source, score, keywords, url, created_at
            FROM trending_ideas
            WHERE used = FALSE
            ORDER BY score DESC
            LIMIT ?
        ''', (limit,))
        
        ideas = []
        for row in cursor.fetchall():
            ideas.append({
                'id': row[0],
                'title': row[1],
                'source': row[2],
                'score': row[3],
                'keywords': row[4],
                'url': row[5],
                'created_at': row[6]
            })
        
        conn.close()
        return ideas
    
    def mark_idea_as_used(self, idea_id: int):
        """
        Mark an idea as used in the database.
        
        Args:
            idea_id: ID of the idea to mark as used
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE trending_ideas SET used = TRUE WHERE id = ?",
            (idea_id,)
        )
        
        conn.commit()
        conn.close()
    
    def discover_trending_ideas(self) -> List[Dict[str, Any]]:
        """
        Main method to discover and return trending ideas.
        
        Returns:
            List of top trending ideas ready for content creation
        """
        print("Starting trending ideas discovery...")
        
        # Collect ideas from various sources
        all_ideas = []
        
        # Get Reddit trends
        print("Fetching Reddit trends...")
        reddit_ideas = self.get_reddit_trends()
        all_ideas.extend(reddit_ideas)
        
        # Get YouTube trends (placeholder)
        print("Fetching YouTube trends...")
        youtube_ideas = self.get_youtube_trends()
        all_ideas.extend(youtube_ideas)
        
        # Analyze and score ideas
        print("Analyzing and scoring ideas...")
        scored_ideas = self.analyze_and_score_ideas(all_ideas)
        
        # Save to database
        print("Saving ideas to database...")
        self.save_ideas_to_db(scored_ideas)
        
        # Get top unused ideas
        top_ideas = self.get_top_unused_ideas(limit=10)
        
        print(f"Discovery complete. Found {len(top_ideas)} top trending ideas.")
        return top_ideas

def main():
    """Test the trending discovery component."""
    # Example niche keywords for a tech/AI channel
    niche_keywords = ['AI', 'artificial intelligence', 'technology', 'automation', 'machine learning', 'robots']
    
    # Initialize the discovery component
    discovery = TrendingDiscovery(niche_keywords)
    
    # Discover trending ideas
    trending_ideas = discovery.discover_trending_ideas()
    
    # Display results
    print("\n=== TOP TRENDING IDEAS ===")
    for i, idea in enumerate(trending_ideas[:5], 1):
        print(f"\n{i}. {idea['title']}")
        print(f"   Source: {idea['source']}")
        print(f"   Score: {idea['score']}")
        print(f"   Keywords: {idea['keywords']}")
        print(f"   URL: {idea['url']}")

if __name__ == "__main__":
    main()


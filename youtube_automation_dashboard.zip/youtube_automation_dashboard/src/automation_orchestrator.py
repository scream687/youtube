#!/usr/bin/env python3
"""
Automation Orchestrator
This module orchestrates the complete YouTube automation workflow.
"""

import os
import json
import time
import schedule
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging

from enhanced_trending_discovery import EnhancedTrendingDiscovery
from prompt_generator import PromptGenerator
from video_generator import VideoGenerator
from youtube_uploader import YouTubeUploader
from analytics_tracker import AnalyticsTracker
from dashboard_generator import DashboardGenerator
from content_creation_system import ContentCreationSystem

class AutomationOrchestrator:
    def __init__(self, config_path: str = 'automation_config.json'):
        """
        Initialize the automation orchestrator.
        
        Args:
            config_path: Path to the configuration file
        """
        self.config_path = config_path
        self.config = self.load_config()
        
        # Set up logging
        self.setup_logging()
        
        # Initialize all components
        self.content_system = ContentCreationSystem(self.config)
        self.uploader = YouTubeUploader(
            credentials_path=self.config.get('youtube_credentials_path'),
            token_path=self.config.get('youtube_token_path')
        )
        self.analytics_tracker = AnalyticsTracker(self.config.get('analytics', {}))
        self.dashboard_generator = DashboardGenerator(
            self.config.get('analytics', {}).get('analytics_db_path', 'youtube_analytics.db')
        )
        
        # Automation settings
        self.automation_enabled = self.config.get('automation_enabled', True)
        self.daily_video_count = self.config.get('daily_video_count', 1)
        self.upload_schedule = self.config.get('upload_schedule', '09:00')
        self.analytics_update_schedule = self.config.get('analytics_update_schedule', '18:00')
        
        # State tracking
        self.last_run_date = None
        self.total_videos_created = 0
        self.total_videos_uploaded = 0
        
        self.logger.info("Automation Orchestrator initialized successfully")
    
    def load_config(self) -> Dict[str, Any]:
        """
        Load configuration from file or create default config.
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                return json.load(f)
        else:
            # Create default configuration
            default_config = {
                "automation_enabled": True,
                "daily_video_count": 1,
                "upload_schedule": "09:00",
                "analytics_update_schedule": "18:00",
                "niche_keywords": [
                    "AI", "artificial intelligence", "technology", "automation",
                    "machine learning", "robots", "future", "innovation"
                ],
                "video_api": {
                    "provider": "mock_api"
                },
                "youtube_credentials_path": "youtube_credentials.json",
                "youtube_token_path": "youtube_token.pickle",
                "analytics": {
                    "analytics_db_path": "youtube_analytics.db",
                    "mock_mode": True,
                    "google_sheets_enabled": False
                },
                "content_types": ["technology", "educational"],
                "video_duration": "medium",
                "output_dir": "/tmp/youtube_automation"
            }
            
            # Save default config
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            
            return default_config
    
    def setup_logging(self):
        """Set up logging configuration."""
        log_level = self.config.get('log_level', 'INFO')
        log_file = self.config.get('log_file', 'youtube_automation.log')
        
        logging.basicConfig(
            level=getattr(logging, log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        self.logger = logging.getLogger('AutomationOrchestrator')
    
    def run_daily_automation(self):
        """Run the complete daily automation workflow."""
        if not self.automation_enabled:
            self.logger.info("Automation is disabled, skipping daily run")
            return
        
        self.logger.info("🚀 Starting daily automation workflow")
        
        try:
            # Step 1: Create video content
            self.logger.info("Step 1: Creating video content")
            created_content = self.content_system.batch_create_content(
                num_videos=self.daily_video_count
            )
            
            if not created_content:
                self.logger.warning("No content was created, stopping workflow")
                return
            
            # Step 2: Upload videos to YouTube
            self.logger.info("Step 2: Uploading videos to YouTube")
            ready_content = [c for c in created_content if c.get('ready_for_upload')]
            
            if ready_content:
                upload_results = self.uploader.batch_upload_videos(ready_content)
                
                # Step 3: Add uploaded videos to analytics tracking
                self.logger.info("Step 3: Adding videos to analytics tracking")
                for content, upload_result in zip(ready_content, upload_results):
                    if upload_result.get('success'):
                        self.analytics_tracker.add_video_to_tracking(content, upload_result)
                        self.total_videos_uploaded += 1
                
                self.total_videos_created += len(ready_content)
            else:
                self.logger.warning("No content ready for upload")
            
            # Step 4: Update analytics for existing videos
            self.logger.info("Step 4: Updating analytics for existing videos")
            self.analytics_tracker.update_all_video_analytics()
            
            # Step 5: Generate dashboard
            self.logger.info("Step 5: Generating analytics dashboard")
            dashboard_paths = self.dashboard_generator.generate_complete_dashboard()
            
            self.last_run_date = datetime.now().date()
            self.logger.info("✅ Daily automation workflow completed successfully")
            
            # Log summary
            self.log_daily_summary(created_content, upload_results if 'upload_results' in locals() else [])
            
        except Exception as e:
            self.logger.error(f"❌ Error in daily automation workflow: {str(e)}")
            raise
    
    def run_analytics_update(self):
        """Run analytics update workflow."""
        self.logger.info("📊 Running analytics update")
        
        try:
            # Update all video analytics
            self.analytics_tracker.update_all_video_analytics()
            
            # Generate fresh dashboard
            dashboard_paths = self.dashboard_generator.generate_complete_dashboard()
            
            self.logger.info("✅ Analytics update completed successfully")
            
        except Exception as e:
            self.logger.error(f"❌ Error in analytics update: {str(e)}")
    
    def log_daily_summary(self, created_content: List[Dict], upload_results: List[Dict]):
        """
        Log a summary of the daily automation run.
        
        Args:
            created_content: List of created content
            upload_results: List of upload results
        """
        successful_uploads = len([r for r in upload_results if r.get('success')])
        failed_uploads = len(upload_results) - successful_uploads
        
        summary = f"""
        📊 DAILY AUTOMATION SUMMARY
        ===========================
        Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        Content Created: {len(created_content)}
        Videos Uploaded: {successful_uploads}
        Upload Failures: {failed_uploads}
        Total Videos Created (All Time): {self.total_videos_created}
        Total Videos Uploaded (All Time): {self.total_videos_uploaded}
        """
        
        self.logger.info(summary)
    
    def setup_schedule(self):
        """Set up the automation schedule."""
        if not self.automation_enabled:
            self.logger.info("Automation is disabled, not setting up schedule")
            return
        
        # Schedule daily content creation and upload
        schedule.every().day.at(self.upload_schedule).do(self.run_daily_automation)
        
        # Schedule analytics updates
        schedule.every().day.at(self.analytics_update_schedule).do(self.run_analytics_update)
        
        # Schedule weekly dashboard generation
        schedule.every().sunday.at("20:00").do(self.generate_weekly_report)
        
        self.logger.info(f"Automation scheduled:")
        self.logger.info(f"  - Daily content creation: {self.upload_schedule}")
        self.logger.info(f"  - Analytics updates: {self.analytics_update_schedule}")
        self.logger.info(f"  - Weekly reports: Sunday 20:00")
    
    def generate_weekly_report(self):
        """Generate a comprehensive weekly report."""
        self.logger.info("📈 Generating weekly report")
        
        try:
            # Generate performance report
            report = self.analytics_tracker.generate_performance_report(days=7)
            
            # Export to CSV
            csv_path = self.analytics_tracker.export_to_csv(
                f"weekly_report_{datetime.now().strftime('%Y%m%d')}.csv"
            )
            
            # Generate dashboard
            dashboard_paths = self.dashboard_generator.generate_complete_dashboard(days=7)
            
            # Save weekly report
            report_path = f"weekly_report_{datetime.now().strftime('%Y%m%d')}.json"
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            self.logger.info(f"✅ Weekly report generated: {report_path}")
            
        except Exception as e:
            self.logger.error(f"❌ Error generating weekly report: {str(e)}")
    
    def run_manual_workflow(self, num_videos: int = 1):
        """
        Run the automation workflow manually.
        
        Args:
            num_videos: Number of videos to create
        """
        self.logger.info(f"🎬 Running manual workflow for {num_videos} videos")
        
        # Temporarily override daily video count
        original_count = self.daily_video_count
        self.daily_video_count = num_videos
        
        try:
            self.run_daily_automation()
        finally:
            # Restore original count
            self.daily_video_count = original_count
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get the current status of the automation system.
        
        Returns:
            System status information
        """
        # Get recent performance data
        report = self.analytics_tracker.generate_performance_report(days=7)
        
        status = {
            'automation_enabled': self.automation_enabled,
            'last_run_date': self.last_run_date.isoformat() if self.last_run_date else None,
            'total_videos_created': self.total_videos_created,
            'total_videos_uploaded': self.total_videos_uploaded,
            'daily_video_count': self.daily_video_count,
            'upload_schedule': self.upload_schedule,
            'analytics_update_schedule': self.analytics_update_schedule,
            'recent_performance': report['overall_statistics'],
            'system_health': 'healthy',  # Could be enhanced with actual health checks
            'next_scheduled_run': self.get_next_scheduled_run()
        }
        
        return status
    
    def get_next_scheduled_run(self) -> str:
        """
        Get the next scheduled run time.
        
        Returns:
            Next scheduled run time as ISO string
        """
        try:
            next_run = schedule.next_run()
            return next_run.isoformat() if next_run else "Not scheduled"
        except:
            return "Unknown"
    
    def start_automation(self):
        """Start the automation system with scheduling."""
        self.logger.info("🚀 Starting YouTube Automation System")
        
        # Set up schedule
        self.setup_schedule()
        
        # Run initial status check
        status = self.get_system_status()
        self.logger.info(f"System Status: {json.dumps(status, indent=2)}")
        
        # Main automation loop
        self.logger.info("Automation system is running. Press Ctrl+C to stop.")
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            self.logger.info("Automation system stopped by user")
        except Exception as e:
            self.logger.error(f"Automation system error: {str(e)}")
            raise

def main():
    """Test the automation orchestrator."""
    print("=== YOUTUBE AUTOMATION ORCHESTRATOR TEST ===")
    
    # Initialize orchestrator
    orchestrator = AutomationOrchestrator()
    
    # Test manual workflow
    print("\n🎬 Testing manual workflow...")
    orchestrator.run_manual_workflow(num_videos=1)
    
    # Test analytics update
    print("\n📊 Testing analytics update...")
    orchestrator.run_analytics_update()
    
    # Test weekly report
    print("\n📈 Testing weekly report generation...")
    orchestrator.generate_weekly_report()
    
    # Display system status
    print("\n📋 System Status:")
    status = orchestrator.get_system_status()
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    print("\n✅ Orchestrator test completed!")
    print("\nTo start the automation system, run:")
    print("  orchestrator.start_automation()")

if __name__ == "__main__":
    main()


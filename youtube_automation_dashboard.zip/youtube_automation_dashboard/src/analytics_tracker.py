#!/usr/bin/env python3
"""
Analytics Tracker Module
This module tracks YouTube video performance and creates analytics dashboards.
"""

import os
import json
import time
import csv
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import sqlite3

# For Google Sheets integration (would need: pip install gspread google-auth)
# import gspread
# from google.oauth2.service_account import Credentials

class AnalyticsTracker:
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the analytics tracker.
        
        Args:
            config: Configuration dictionary containing API keys and settings
        """
        self.config = config or {}
        
        # Database for storing analytics data
        self.db_path = self.config.get('analytics_db_path', 'youtube_analytics.db')
        
        # Google Sheets configuration
        self.sheets_enabled = self.config.get('google_sheets_enabled', False)
        self.spreadsheet_id = self.config.get('spreadsheet_id')
        self.service_account_path = self.config.get('service_account_path')
        
        # Mock mode for testing
        self.mock_mode = self.config.get('mock_mode', True)
        
        # Initialize database
        self.init_database()
        
        # Initialize Google Sheets (if enabled)
        self.sheets_client = None
        if self.sheets_enabled and not self.mock_mode:
            self.sheets_client = self._init_google_sheets()
    
    def init_database(self):
        """Initialize SQLite database for analytics data."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create videos table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                content_type TEXT,
                trending_source TEXT,
                video_url TEXT,
                status TEXT DEFAULT 'uploaded'
            )
        ''')
        
        # Create analytics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT NOT NULL,
                date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                views INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                dislikes INTEGER DEFAULT 0,
                comments INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                watch_time_minutes REAL DEFAULT 0,
                subscribers_gained INTEGER DEFAULT 0,
                revenue_usd REAL DEFAULT 0,
                ctr_percentage REAL DEFAULT 0,
                avg_view_duration_seconds REAL DEFAULT 0,
                FOREIGN KEY (video_id) REFERENCES videos (video_id)
            )
        ''')
        
        # Create performance summary table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_summary (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date_recorded DATE UNIQUE,
                total_videos INTEGER DEFAULT 0,
                total_views INTEGER DEFAULT 0,
                total_subscribers INTEGER DEFAULT 0,
                total_revenue REAL DEFAULT 0,
                avg_ctr REAL DEFAULT 0,
                top_performing_video TEXT,
                content_type_performance TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _init_google_sheets(self):
        """
        Initialize Google Sheets client.
        
        Returns:
            Google Sheets client or None
        """
        try:
            # Real implementation would be:
            # scopes = [
            #     'https://www.googleapis.com/auth/spreadsheets',
            #     'https://www.googleapis.com/auth/drive'
            # ]
            # 
            # credentials = Credentials.from_service_account_file(
            #     self.service_account_path, scopes=scopes
            # )
            # 
            # return gspread.authorize(credentials)
            
            print("⚠️  Google Sheets integration not implemented in mock mode")
            return None
            
        except Exception as e:
            print(f"Error initializing Google Sheets: {str(e)}")
            return None
    
    def add_video_to_tracking(self, video_metadata: Dict[str, Any], upload_result: Dict[str, Any]):
        """
        Add a newly uploaded video to the tracking system.
        
        Args:
            video_metadata: Original video metadata
            upload_result: Result from YouTube upload
        """
        if not upload_result.get('success'):
            print(f"❌ Cannot track failed upload")
            return
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            video_prompt = video_metadata.get('video_prompt', {})
            trending_idea = video_metadata.get('trending_idea', {})
            
            cursor.execute('''
                INSERT OR REPLACE INTO videos 
                (video_id, title, content_type, trending_source, video_url, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                upload_result['video_id'],
                upload_result['title'],
                trending_idea.get('content_type', 'unknown'),
                trending_idea.get('source', 'unknown'),
                upload_result['video_url'],
                'uploaded'
            ))
            
            conn.commit()
            print(f"✅ Added video {upload_result['video_id']} to tracking")
            
        except Exception as e:
            print(f"Error adding video to tracking: {str(e)}")
        finally:
            conn.close()
    
    def fetch_video_analytics(self, video_id: str) -> Dict[str, Any]:
        """
        Fetch analytics data for a specific video.
        
        Args:
            video_id: YouTube video ID
            
        Returns:
            Analytics data for the video
        """
        if self.mock_mode:
            return self._generate_mock_analytics(video_id)
        
        # Real implementation would use YouTube Analytics API
        return self._fetch_real_analytics(video_id)
    
    def _generate_mock_analytics(self, video_id: str) -> Dict[str, Any]:
        """
        Generate mock analytics data for testing.
        
        Args:
            video_id: YouTube video ID
            
        Returns:
            Mock analytics data
        """
        import random
        
        # Generate realistic mock data
        base_views = random.randint(1000, 50000)
        
        analytics = {
            'video_id': video_id,
            'views': base_views,
            'likes': int(base_views * random.uniform(0.02, 0.08)),
            'dislikes': int(base_views * random.uniform(0.001, 0.01)),
            'comments': int(base_views * random.uniform(0.005, 0.03)),
            'shares': int(base_views * random.uniform(0.001, 0.005)),
            'watch_time_minutes': base_views * random.uniform(2.5, 8.0),
            'subscribers_gained': random.randint(10, 200),
            'revenue_usd': base_views * random.uniform(0.001, 0.005),
            'ctr_percentage': random.uniform(3.0, 12.0),
            'avg_view_duration_seconds': random.uniform(120, 480),
            'fetched_at': datetime.now().isoformat()
        }
        
        return analytics
    
    def _fetch_real_analytics(self, video_id: str) -> Dict[str, Any]:
        """
        Fetch real analytics data using YouTube Analytics API.
        
        Args:
            video_id: YouTube video ID
            
        Returns:
            Real analytics data
        """
        # Real implementation would be:
        # from googleapiclient.discovery import build
        # 
        # youtube_analytics = build('youtubeAnalytics', 'v2', credentials=credentials)
        # 
        # response = youtube_analytics.reports().query(
        #     ids='channel==MINE',
        #     startDate='2023-01-01',
        #     endDate='2023-12-31',
        #     metrics='views,likes,dislikes,comments,shares,estimatedMinutesWatched,subscribersGained',
        #     dimensions='video',
        #     filters=f'video=={video_id}'
        # ).execute()
        
        return {
            'video_id': video_id,
            'views': 0,
            'likes': 0,
            'comments': 0,
            'error': 'Real analytics API not implemented'
        }
    
    def update_video_analytics(self, video_id: str):
        """
        Update analytics data for a specific video.
        
        Args:
            video_id: YouTube video ID
        """
        print(f"📊 Updating analytics for video {video_id}")
        
        # Fetch latest analytics
        analytics = self.fetch_video_analytics(video_id)
        
        if 'error' in analytics:
            print(f"❌ Error fetching analytics: {analytics['error']}")
            return
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO analytics 
                (video_id, views, likes, dislikes, comments, shares, 
                 watch_time_minutes, subscribers_gained, revenue_usd, 
                 ctr_percentage, avg_view_duration_seconds)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                video_id,
                analytics.get('views', 0),
                analytics.get('likes', 0),
                analytics.get('dislikes', 0),
                analytics.get('comments', 0),
                analytics.get('shares', 0),
                analytics.get('watch_time_minutes', 0),
                analytics.get('subscribers_gained', 0),
                analytics.get('revenue_usd', 0),
                analytics.get('ctr_percentage', 0),
                analytics.get('avg_view_duration_seconds', 0)
            ))
            
            conn.commit()
            print(f"✅ Analytics updated for video {video_id}")
            
        except Exception as e:
            print(f"Error storing analytics: {str(e)}")
        finally:
            conn.close()
    
    def update_all_video_analytics(self):
        """Update analytics for all tracked videos."""
        print("📊 Updating analytics for all tracked videos...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all video IDs
        cursor.execute("SELECT video_id FROM videos WHERE status = 'uploaded'")
        video_ids = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        print(f"Found {len(video_ids)} videos to update")
        
        for i, video_id in enumerate(video_ids):
            print(f"Updating {i+1}/{len(video_ids)}: {video_id}")
            self.update_video_analytics(video_id)
            
            # Rate limiting
            if i < len(video_ids) - 1:
                time.sleep(2)
        
        print("✅ All video analytics updated")
    
    def generate_performance_report(self, days: int = 30) -> Dict[str, Any]:
        """
        Generate a comprehensive performance report.
        
        Args:
            days: Number of days to include in the report
            
        Returns:
            Performance report data
        """
        print(f"📈 Generating performance report for last {days} days...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Get overall statistics
        cursor.execute('''
            SELECT 
                COUNT(DISTINCT v.video_id) as total_videos,
                SUM(a.views) as total_views,
                SUM(a.likes) as total_likes,
                SUM(a.comments) as total_comments,
                SUM(a.subscribers_gained) as total_subscribers_gained,
                SUM(a.revenue_usd) as total_revenue,
                AVG(a.ctr_percentage) as avg_ctr,
                AVG(a.avg_view_duration_seconds) as avg_duration
            FROM videos v
            LEFT JOIN analytics a ON v.video_id = a.video_id
            WHERE a.date_recorded >= ?
        ''', (start_date.isoformat(),))
        
        overall_stats = cursor.fetchone()
        
        # Get top performing videos
        cursor.execute('''
            SELECT 
                v.video_id, v.title, v.content_type,
                MAX(a.views) as max_views,
                MAX(a.likes) as max_likes,
                MAX(a.ctr_percentage) as max_ctr
            FROM videos v
            LEFT JOIN analytics a ON v.video_id = a.video_id
            WHERE a.date_recorded >= ?
            GROUP BY v.video_id
            ORDER BY max_views DESC
            LIMIT 10
        ''', (start_date.isoformat(),))
        
        top_videos = cursor.fetchall()
        
        # Get performance by content type
        cursor.execute('''
            SELECT 
                v.content_type,
                COUNT(DISTINCT v.video_id) as video_count,
                AVG(a.views) as avg_views,
                AVG(a.ctr_percentage) as avg_ctr,
                SUM(a.revenue_usd) as total_revenue
            FROM videos v
            LEFT JOIN analytics a ON v.video_id = a.video_id
            WHERE a.date_recorded >= ?
            GROUP BY v.content_type
            ORDER BY avg_views DESC
        ''', (start_date.isoformat(),))
        
        content_type_performance = cursor.fetchall()
        
        conn.close()
        
        # Compile report
        report = {
            'report_generated': datetime.now().isoformat(),
            'period_days': days,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'overall_statistics': {
                'total_videos': overall_stats[0] or 0,
                'total_views': overall_stats[1] or 0,
                'total_likes': overall_stats[2] or 0,
                'total_comments': overall_stats[3] or 0,
                'total_subscribers_gained': overall_stats[4] or 0,
                'total_revenue_usd': round(overall_stats[5] or 0, 2),
                'average_ctr_percentage': round(overall_stats[6] or 0, 2),
                'average_view_duration_seconds': round(overall_stats[7] or 0, 2)
            },
            'top_performing_videos': [
                {
                    'video_id': video[0],
                    'title': video[1],
                    'content_type': video[2],
                    'views': video[3],
                    'likes': video[4],
                    'ctr_percentage': round(video[5] or 0, 2)
                }
                for video in top_videos
            ],
            'content_type_performance': [
                {
                    'content_type': content[0],
                    'video_count': content[1],
                    'average_views': round(content[2] or 0, 0),
                    'average_ctr': round(content[3] or 0, 2),
                    'total_revenue': round(content[4] or 0, 2)
                }
                for content in content_type_performance
            ]
        }
        
        return report
    
    def export_to_csv(self, output_path: str = None) -> str:
        """
        Export analytics data to CSV file.
        
        Args:
            output_path: Path for the CSV file
            
        Returns:
            Path to the exported CSV file
        """
        if output_path is None:
            output_path = f"youtube_analytics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all analytics data with video information
        cursor.execute('''
            SELECT 
                v.video_id, v.title, v.content_type, v.trending_source, v.upload_date,
                a.date_recorded, a.views, a.likes, a.dislikes, a.comments, a.shares,
                a.watch_time_minutes, a.subscribers_gained, a.revenue_usd,
                a.ctr_percentage, a.avg_view_duration_seconds
            FROM videos v
            LEFT JOIN analytics a ON v.video_id = a.video_id
            ORDER BY a.date_recorded DESC
        ''')
        
        data = cursor.fetchall()
        conn.close()
        
        # Write to CSV
        with open(output_path, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            
            # Write header
            writer.writerow([
                'Video ID', 'Title', 'Content Type', 'Trending Source', 'Upload Date',
                'Analytics Date', 'Views', 'Likes', 'Dislikes', 'Comments', 'Shares',
                'Watch Time (min)', 'Subscribers Gained', 'Revenue (USD)',
                'CTR (%)', 'Avg View Duration (sec)'
            ])
            
            # Write data
            writer.writerows(data)
        
        print(f"✅ Analytics data exported to {output_path}")
        return output_path
    
    def update_google_sheets(self, spreadsheet_id: str = None):
        """
        Update Google Sheets with latest analytics data.
        
        Args:
            spreadsheet_id: Google Sheets spreadsheet ID
        """
        if not self.sheets_client:
            print("❌ Google Sheets client not initialized")
            return
        
        if not spreadsheet_id:
            spreadsheet_id = self.spreadsheet_id
        
        if not spreadsheet_id:
            print("❌ No spreadsheet ID provided")
            return
        
        try:
            # Real implementation would be:
            # spreadsheet = self.sheets_client.open_by_key(spreadsheet_id)
            # worksheet = spreadsheet.worksheet('Analytics')
            # 
            # # Get data from database
            # conn = sqlite3.connect(self.db_path)
            # cursor = conn.cursor()
            # cursor.execute("SELECT * FROM analytics ORDER BY date_recorded DESC")
            # data = cursor.fetchall()
            # conn.close()
            # 
            # # Update worksheet
            # worksheet.clear()
            # worksheet.update('A1', [['Video ID', 'Views', 'Likes', ...]] + data)
            
            print(f"✅ Mock: Google Sheets updated with latest analytics")
            
        except Exception as e:
            print(f"Error updating Google Sheets: {str(e)}")

def main():
    """Test the analytics tracker."""
    # Configuration
    config = {
        'analytics_db_path': '/tmp/test_youtube_analytics.db',
        'mock_mode': True,
        'google_sheets_enabled': False
    }
    
    # Initialize tracker
    tracker = AnalyticsTracker(config)
    
    # Test adding videos to tracking
    print("=== TESTING VIDEO TRACKING ===")
    
    sample_metadata = {
        'video_prompt': {
            'video_title': 'Amazing AI Breakthrough',
            'content_type': 'technology'
        },
        'trending_idea': {
            'content_type': 'technology',
            'source': 'reddit_technology'
        }
    }
    
    sample_upload_result = {
        'success': True,
        'video_id': 'test_video_001',
        'video_url': 'https://youtube.com/watch?v=test_video_001',
        'title': 'Amazing AI Breakthrough'
    }
    
    tracker.add_video_to_tracking(sample_metadata, sample_upload_result)
    
    # Test analytics update
    print("\n=== TESTING ANALYTICS UPDATE ===")
    tracker.update_video_analytics('test_video_001')
    
    # Add more test data
    for i in range(2, 6):
        test_result = sample_upload_result.copy()
        test_result['video_id'] = f'test_video_{i:03d}'
        test_result['video_url'] = f'https://youtube.com/watch?v=test_video_{i:03d}'
        tracker.add_video_to_tracking(sample_metadata, test_result)
        tracker.update_video_analytics(f'test_video_{i:03d}')
    
    # Test performance report
    print("\n=== TESTING PERFORMANCE REPORT ===")
    report = tracker.generate_performance_report(days=30)
    
    print(f"Total Videos: {report['overall_statistics']['total_videos']}")
    print(f"Total Views: {report['overall_statistics']['total_views']:,}")
    print(f"Total Revenue: ${report['overall_statistics']['total_revenue_usd']:.2f}")
    print(f"Average CTR: {report['overall_statistics']['average_ctr_percentage']:.2f}%")
    
    print("\nTop Performing Videos:")
    for video in report['top_performing_videos'][:3]:
        print(f"  {video['title']}: {video['views']:,} views")
    
    # Test CSV export
    print("\n=== TESTING CSV EXPORT ===")
    csv_path = tracker.export_to_csv('/tmp/test_analytics_export.csv')
    print(f"CSV exported to: {csv_path}")

if __name__ == "__main__":
    main()

